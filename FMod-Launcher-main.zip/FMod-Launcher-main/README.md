Hi im burlone413, i made the launcher for Fake FMod server, i'm publishing the launcher to let everyone know that I didn't rat the launcher and that it's the redirect that has the rat, this version still contains the rat (download the redirect), if you want to use it for your project go ahead but be careful and give credits to burlone413

## Where was the Rat?
About the RAT / how to remove it: https://github.com/Lucasfrfr/fmod-luckyware-rat

'src/main/main.js' and its the redirect dll download URL at the line **`206`** and the link is dead so it will not rat you again:P

<!-- 
## A Chaos happened with the RAT involved!!!
Burlone my friend got hacked recently because of the "Luckware" rat that the dll had!

The Screenshot is from Project Interlude (Burlone's co-owned project with Andingly) Do NOT download or use ANY **FAKE**  FMod projects and stay safe!!!
<img width="1130" height="700" alt="image" src="https://github.com/user-attachments/assets/dc4aa14a-a88f-413f-95d8-c916cd21a52c" />
-->

## How to build / use

- Install [**node.js**](https://nodejs.org/en)
- Install **node_modules** packages with:
```js
npm i
// OR
npm install
```
- Build the exe with:
```js
npm run build
```
and the setup exe file should be in this output: **`FMod-Launcher-main\dist\build`** </br>

- Make a Login api for the backend + to the launcher in `FMod-Launcher-main\src\main\main.js` </br>
**OR** </br>
DM my friend `@kumailala` (ID:913777634079539240) on discord to make an Api code for you for Both Backend and Laucnher **(PAID)**
